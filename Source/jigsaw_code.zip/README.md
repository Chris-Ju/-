# Jigsaw
See [N Puzzle](https://se-2018.github.io/Stage3--NPuzzle)。


## Task
Finish class `Solution`.

## Build 
```shell
# compile
javac -encoding UTF-8 -d build -cp . solution/main.java

# run
java -cp build solution.main
```
