/*
 * Copyright (c) 2018, SYSU and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 */

package solution;

import solution.Solution;
import jigsaw.JigsawNode;
import jigsaw.Jigsaw;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Vector;

/**
 * 
 * <p>This class judge 
 * <a href="https://se-2018.github.io/Stage3--NPuzzle">
 * N-Puzzle</a> experimental task.
 * @author  se-2018
 */
public class main {
    private final static int BFS_LENGTH = 10;
    private final static int ASTAR_LOWER_LIMIT = 1000;
    private final static int ASTAR_UPPER_LIMIT = 15000;

    private final static int BFS_SCORE = 2;
    private final static int ASTAR_SCORE = 14;

    private final static String OUT = "score.txt";

    public static int calBFSScore(int length) {
        if (length == BFS_LENGTH) {
            return (int)(BFS_SCORE);
        }
        return 0;
    }

    public static int calAStarScore(double searchedNodesNum) {
        double score = (ASTAR_UPPER_LIMIT - searchedNodesNum) / (ASTAR_UPPER_LIMIT - ASTAR_LOWER_LIMIT) * ASTAR_SCORE;
        return Math.min(ASTAR_SCORE, (int)Math.max(0, score));
    }


    public static int TestBFS() {
        JigsawNode destNode = new JigsawNode(new int[]{25,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,0});
        JigsawNode startNode = new JigsawNode(new int[]{16,1,2,3,4,5,6,7,8,9,10,11,18,12,14,15,0,16,13,19,20,21,17,22,23,24});

        Solution solution = new Solution(startNode, destNode);

        try {
            if (!solution.BFSearch()) {
                return 0;
            }
        } catch (Throwable th) {
            return 0;
        }

        Vector<JigsawNode> solutionPath = solution.getPath();
        if (!solution.isValidPath(solutionPath, startNode, destNode)) {
            return 0;
        }

        return calBFSScore(solutionPath.size());
    }


    public static int TestAStar() {
        JigsawNode destNode = new JigsawNode(new int[]{25,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,0});

        JigsawNode startNode = Jigsaw.scatter(destNode, 1000);

        Solution solution = new Solution(startNode, destNode);

        try {
            if (!solution.ASearch()) {
                return 0;
            }
        } catch (Throwable th) {
            return 0;
        }

        Vector<JigsawNode> solutionPath = solution.getPath();
        if (!solution.isValidPath(solutionPath, startNode, destNode)) {
            return 0;
        }

        return calAStarScore(solution.getSearchedNodesNum());
    }


	/**
     * 
	 * @param args
	 */
	public static void main(String[] args) {
        try {
            PrintWriter pw = new PrintWriter(new FileWriter(OUT));
            pw.println(TestBFS() + TestAStar());
            pw.close();
        } catch (Throwable th) {
        }
	}

}

        